# Databricks notebook source
# MAGIC %md
# MAGIC #### Data Reading from Silver Layer

# COMMAND ----------

df = spark.read.format("delta").load("/Volumes/netflix_catalog/netflix_schema/cleaned")
df.display()

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Creating Fact table

# COMMAND ----------

if spark.catalog.tableExists('netflix_catalog.netflix_schema.netflix_facttbl'):
    pass
else:
    # Creating Empty Fact Table
    print("Creating Empty Fact Table")
    df_fact = df.select(['show_id','type','title','date_added','release_year','rating','duration','duration_type']) \
                .filter("1=0")
    
    df_fact.write.saveAsTable("netflix_catalog.netflix_schema.netflix_facttbl")

    # Applying Constraints
    spark.sql("""
        ALTER TABLE netflix_catalog.netflix_schema.netflix_facttbl
        ADD CONSTRAINT all_not_nulls CHECK (
            show_id IS NOT NULL AND
            type IS NOT NULL AND
            title IS NOT NULL AND
            date_added IS NOT NULL AND
            release_year IS NOT NULL AND
            rating IS NOT NULL AND
            duration IS NOT NULL
            duration_type IS NOT NULL
        )
    """)

    # Set Primary Key
    spark.sql("""
        ALTER TABLE netflix_catalog.netflix_schema.netflix_facttbl
        SET TBLPROPERTIES (
            primaryKey = 'show_id'
        )
    """)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED netflix_catalog.netflix_schema.netflix_facttbl;

# COMMAND ----------

# MAGIC %md
# MAGIC #### Loading Data into Fact Table

# COMMAND ----------

df_fact = df.select(['show_id','type','title','date_added','release_year','rating','duration','duration_type'])

# COMMAND ----------

existing = spark.read.table("netflix_catalog.netflix_schema.netflix_facttbl").select("show_id")
new_df = df_fact.join(existing, on="show_id", how="left_anti")

# COMMAND ----------

new_df.write.mode("append").saveAsTable("netflix_catalog.netflix_schema.netflix_facttbl")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from netflix_catalog.netflix_schema.netflix_facttbl order by date_added asc;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS total_rows FROM netflix_catalog.netflix_schema.netflix_facttbl;