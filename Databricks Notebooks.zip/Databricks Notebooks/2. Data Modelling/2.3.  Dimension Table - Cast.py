# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC #### Data Reading from Silver Layer

# COMMAND ----------

df = spark.read.format("delta").load("/Volumes/netflix_catalog/netflix_schema/cleaned")
df.display()

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Creating Dimension table

# COMMAND ----------

if spark.catalog.tableExists('netflix_catalog.netflix_schema.netflix_dim_cast'):
    pass
else:
    # Creating Empty Dimension Table
    print("Creating Empty Dimension Table")
    df_dim = df.select(['show_id','cast']) \
                .filter("1=0")
    
    df_dim.write.saveAsTable("netflix_catalog.netflix_schema.netflix_dim_cast")

    # Applying Constraints
    spark.sql("""
        ALTER TABLE netflix_catalog.netflix_schema.netflix_dim_cast
        ADD CONSTRAINT all_not_nulls CHECK (
            show_id IS NOT NULL AND
            cast IS NOT NULL 
        )
    """)

    # Set Primary Key
    spark.sql("""
        ALTER TABLE netflix_catalog.netflix_schema.netflix_dim_cast
        SET TBLPROPERTIES (
            primaryKey = 'show_id, cast'
        )
    """)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED netflix_catalog.netflix_schema.netflix_dim_cast;

# COMMAND ----------

# MAGIC %md
# MAGIC #### Loading Data into Dimension Table

# COMMAND ----------

df_dim = df.select(['show_id','cast'])

# COMMAND ----------

existing = spark.read.table("netflix_catalog.netflix_schema.netflix_dim_cast").select("show_id")
new_df = df_dim.join(existing, on="show_id", how="left_anti")

# COMMAND ----------

new_df.display()

# COMMAND ----------

new_df = new_df.withColumn("cast", explode(split(col("cast"), ","))) \
              .withColumn("cast", trim(col("cast")))

# COMMAND ----------

new_df.write.mode("append").saveAsTable("netflix_catalog.netflix_schema.netflix_dim_cast")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from netflix_catalog.netflix_schema.netflix_dim_cast

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS total_rows FROM netflix_catalog.netflix_schema.netflix_dim_cast

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(DISTINCT show_id) AS total_rows FROM netflix_catalog.netflix_schema.netflix_dim_cast